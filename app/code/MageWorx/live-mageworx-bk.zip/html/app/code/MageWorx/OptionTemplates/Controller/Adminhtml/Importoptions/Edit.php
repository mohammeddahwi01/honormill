<?php
namespace MageWorx\OptionTemplates\Controller\Adminhtml\Importoptions;

use Magento\Backend\App\Action;

class Edit extends Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(\Magento\Backend\App\Action\Context $context, \Magento\Framework\Registry $coreRegistry)
    {
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context);
    }

    /**
     * Edit Newsletter Template
     *
     * @return void
     */
    public function execute()
    {
        $this->_view->loadLayout();
        // $this->_setActiveMenu('MageWorx_OptionTemplates::importoptionscsv');

        // $breadcrumbTitle = __('New Template');
        // $breadcrumbLabel = __('Create  Template');
        
        //$this->_view->getPage()->getConfig()->getTitle()->prepend(__(' Templates'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend(
            __('Import Customizable Options CSV')
        );

        // $this->_addBreadcrumb($breadcrumbLabel, $breadcrumbTitle);

        $this->_view->renderLayout();
    }
}