<?php
namespace MageWorx\OptionTemplates\Controller\Adminhtml\Importoptions;
 
use Magento\Backend\App\Action;

class NewAction extends Action
{
    /**
     * Create new Newsletter Template
     *
     * @return void
     */
    public function execute()
    {
        $this->_forward('edit');
    }
}