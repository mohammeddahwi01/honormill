<?php
namespace MageWorx\OptionTemplates\Block\Adminhtml\Importoptions\Edit;

class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    /**
     * @var \Sample\Gridpart2\Helper\Option
     */
    protected $_statusOption;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        array $data = []
    ) {
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Retrieve template object
     *
     * @return \Magento\Newsletter\Model\Template
     */
    public function getModel()
    {
        return $this->_coreRegistry->registry('_gridpart2_template');
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm()
    {
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );

        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Import CSV'), 'class' => 'fieldset-wide']
        );
        //$fieldset->addType('background', 'Sample\Gridpart2\Block\Adminhtml\Template\Helper\Background');
        
       
        $fieldset->addField(
            'upload_csv',
            'file',
            [
                'name' => 'upload_csv',
                'label' => __('Upload CSV'),
                'title' => __('Upload CSV'),
                'required' => true,
                'value' => '',
                'note' => 'NOTE: First export CSV by selecting products that you want to set up values for Fast Ship and Custom Order options. <br> 
                    Go to Catalog > Products. Select products by selecting checkbox than click on actions drop-won and select “Export options to CSV” option from drop-down.',
            ]
        );

        $form->setAction($this->getUrl('*/*/save'));
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}