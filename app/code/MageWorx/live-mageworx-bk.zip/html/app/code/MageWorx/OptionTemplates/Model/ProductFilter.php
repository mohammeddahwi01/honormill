<?php
namespace MageWorx\OptionTemplates\Model;

class ProductFilter implements \Magento\Framework\Option\ArrayInterface
{
 public function toOptionArray()
 {
  $reqData = \Magento\Framework\App\ObjectManager::getInstance()->get('\Magento\Framework\App\Request\Http');
  $reqData = $reqData->getParams();
  if ($reqData != NULL && array_key_exists('group_id', $reqData)) {
    $groupId = $reqData['group_id'];
    return [
      ['value' => $groupId, 'label' => __('Yes')],
      ['value' => 0, 'label' => __('No')]
    ];
  } else {
    return [
      ['value' => 0, 'label' => __('No')]
    ];
  }
 }
}