<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OptionLink\Observer;

use \MageWorx\OptionLink\Helper\Attribute as HelperAttribute;
use \MageWorx\OptionLink\Model\OptionValue as ModelOptionValue;
use \Magento\Store\Model\StoreManagerInterface as StoreManager;
use \Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Event\Observer as EventObserver;

/**
 * Class UpdateOptionValuesBeforeGroupSave. Update option values data linked by SKU to original values data.
 * We save data linked by SKU when unlink option value only.
 * This observer we use when OptionTemplates saving.
 */
class UpdateOptionValuesBeforeGroupSave implements ObserverInterface
{
    protected $_resource;
    protected $_objectManager;
    protected $_messageManager;
    /**
     * @var \MageWorx\OptionLink\Helper\Attribute
     */
    protected $helperAttribute;

    /**
     * @var \MageWorx\OptionLink\Model\OptionValue
     */
    protected $modelOptionValue;

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * UpdateOptionValuesBeforeGroupSave constructor.
     *
     * @param HelperAttribute $helperAttribute
     * @param ModelOptionValue $modelOptionValue
     * @param StoreManager $storeManager
     */
    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectmanager,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        HelperAttribute $helperAttribute,
        ModelOptionValue $modelOptionValue,
        StoreManager $storeManager
    ) {
        $this->_objectManager = $objectmanager;
        $this->_messageManager = $messageManager;
        $this->helperAttribute = $helperAttribute;
        $this->modelOptionValue = $modelOptionValue;
        $this->storeManager = $storeManager;
    }

    /**
     * @param EventObserver $observer
     * @return $this
     */
    public function execute(EventObserver $observer)
    {
        $data = $observer->getRequest()->getParam('mageworx_optiontemplates_group');

        //custom code STARTS
        $action = (null!==$observer->getRequest()->getParam('action')) ? $observer->getRequest()->getParam('action') : '';
        /*echo "<h4>UpdateOptionValuesBeforeGroupSave</h4>";
        echo "<h4>action: ".$action."</h4>";
        echo "<h4>data BEFORE</h4>";
        echo "<pre>";
        print_r($data);
        echo "</pre>";*/
        $this->_resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
        $this->_fileCsv = $this->_objectManager->get('\Magento\Framework\File\Csv');
        $canSaveOptions=$canSaveImages=false;
        if($action=='product_relation')
        {
            $data = $this->doProductRelation($data);
            if(isset($data['error']) && $data['error'])
                $this->_messageManager->addNoticeMessage(__($data['error']));
            else
            {
                $count = (isset($data['products'])) ? count($data['products']) : 0;
                $this->_messageManager->addNoticeMessage(__('%1 product(s) assigned.',$count));
            }
        }
        elseif($action=='replace_options')
        {
            $canSaveOptions = true;
            $data = $this->createReplaceOptions($data, $canSaveOptions, $canSaveImages);
            if(isset($data['error']) && $data['error'])
                $this->_messageManager->addNoticeMessage(__($data['error']));
            else
            {
                $count = (isset($data['optionsCount'])) ? $data['optionsCount'] : 0;
                $this->_messageManager->addNoticeMessage(__('%1 options created/replaced.',$count));
                if($count)
                    $this->_messageManager->addNoticeMessage(__('Now you can sync images/swatches.'));
            }
        }
        elseif($action=='sync_swatches')
        {
            $canSaveImages = (isset($data['options'][0]['values'][0]['mageworx_option_type_id']) && $data['options'][0]['values'][0]['mageworx_option_type_id']) ? true : false;
            if($canSaveImages)
                $data = $this->createReplaceOptions($data, $canSaveOptions, $canSaveImages);
            if(isset($data['error']) && $data['error'])
                $this->_messageManager->addNoticeMessage(__($data['error']));
            else
            {
                $count = (isset($data['swatchesCount'])) ? $data['swatchesCount'] : 0;
                $outof = (isset($data['outof'])) ? $data['outof'] : 0;
                $this->_messageManager->addNoticeMessage(__('%1 out of %2 images/swatches synched.',$count,$outof));
                if(!$count)
                    $this->_messageManager->addNoticeMessage(__('Check if images/swatches exist and not getting synched against each option, if so then click on "Save & Replace Options" then you can sync images/swatches.'));
            }
        }
        if(isset($data['outof']))
            unset($data['outof']);
        if(isset($data['error']))
            unset($data['error']);
        if(isset($data['swatchesCount']))
            unset($data['swatchesCount']);
        if(isset($data['optionsCount']))
            unset($data['optionsCount']);
        /*echo "<h4>data AFTER</h4>";
        echo "<pre>";
        print_r($data);
        echo "</pre>";
        exit();*/
        //custom code ENDS

        if (!isset($data['options'])) {
            return $this;
        }

        $currentOptions = $data['options'];

        $originalValues = $this->getOriginalOptions($currentOptions);
        $fields = $this->helperAttribute->getConvertedAttributesToFields();

        foreach ($currentOptions as $opKey => $currentOption) {
            if (!isset($currentOption['values'])) {
                continue;
            }

            $currentValues = $this->modelOptionValue
                ->updateOptionValuesBeforeSave($currentOption['values'], $originalValues, $fields);

            $data['options'][$opKey]['values'] = $currentValues;
        }
        
        $observer->getRequest()->setParam('mageworx_optiontemplates_group', $data);

        return $this;
    }

    /**
     * Retrieve original option values data by options ids.
     *
     * @param array $options
     * @return array
     */
    protected function getOriginalOptions($options)
    {
        $optionIds = [];
        foreach ($options as $option) {
            $optionIds[] = $option['option_id'];
        }

        return $this->modelOptionValue->loadOriginalOptions($optionIds, false);
    }

    public function createReplaceOptions($data, $canSaveOptions, $canSaveImages)
    {
        if($canSaveOptions || $canSaveImages)
        {
            $file = 'custom_options_group.csv';
            $matchFound = false;
            if (file_exists($file)) {
                $csvData = $this->_fileCsv->getData($file);
                if(count($csvData)) {
                    $title=$rowData="";
                    $njm_group_id = 0;
                    foreach ($csvData as $rowNum => $row) {
                        if(!$matchFound) {
                            if(is_array($row) && count($row)) {
                                foreach ($row as $colNum => $col) {
                                    if($colNum==0)
                                        $njm_group_id = $col;
                                    if($colNum==1)
                                        $title = $col;
                                    if($colNum==2)
                                        $isActive = intval($col);
                                    if($colNum==3)
                                        $rowData = $col;
                                }
                                if($title==$data['title']) {
                                    $matchFound = true;
                                    $data['is_active'] = ($isActive==1) ? 1 : 0;
                                    //$data['njm_group_id'] = $njm_group_id;
                                    $data = $this->saveOptionsProgrammatically($data, $canSaveOptions, $canSaveImages, $rowData, $njm_group_id);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        if(!$matchFound)
            $data['error'] = ('Current Template/Group not found in NJModern site.');
        return $data;
    }

    public function doProductRelation($data)
    {
        //$this->_fileCsv = $this->_objectManager->get('\Magento\Framework\File\Csv');
        $file = 'custom_options_relation_aanddmodern.csv';
        $matchFound = false;
        $aanddmodern_product_ids = array();

        if (file_exists($file)) {
            $csvData = $this->_fileCsv->getData($file);
            if(count($csvData)) {
                $tempArray = array();
                foreach ($csvData as $rowNum => $row) {
                    if($rowNum) {
                        if(is_array($row) && count($row)) {
                            $aanddmodern_product_id = 0;
                            foreach ($row as $colNum => $col) {
                                if($colNum==1) {
                                    $title = $col;
                                }
                                if($colNum==4 && $col) {
                                    $aanddmodern_product_id = intval($col);
                                }
                            }
                            //echo "<br/>(aanddmodern_product_id=$aanddmodern_product_id) (title==data['title']) (".$title."==".$data['title'].")";
                            if($title==$data['title'] && $aanddmodern_product_id) {
                                $matchFound = true;
                                $aanddmodern_product_ids[] = $aanddmodern_product_id;
                            }
                            $aanddmodern_product_id = '';
                        }
                    }
                }                
            }
        }
        if($matchFound && count($aanddmodern_product_ids)) {
            $data['products'] = array_values(array_unique($aanddmodern_product_ids));
        }
        /*echo "<pre>";
        print_r($aanddmodern_product_ids);
        echo "</pre>";
        exit();*/
        if(!$matchFound)
            $data['error'] = ('Current Template/Group not found in NJModern site OR products do not exist in AandDModern site.');
        return $data;
    }

    public function saveOptionsProgrammatically($data, $canSaveOptions, $canSaveImages, $rowData, $njm_group_id=0)
    {
        $connection = $this->_resource->getConnection();
        $tableName = $this->_resource->getTableName('mageworx_optiontemplates_group_option_type_image');
        $fileSystem = $this->_objectManager->create('\Magento\Framework\Filesystem');
        $mediaPath = $fileSystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath()."mageworx/optionfeatures/product/option/value";
        $mainOptionsCount = 0;
        $optionsCount = 0;
        $swatchesCount = 0;
        $prepareOption = array();
        $prepareOptions = array();

        $prepareOption = array(
            'sort_order' => 1,
            'option_id' => '',
            'is_require' => 0,
            'one_time' => 0,
            'description' => '',
            'sku' => '',
            'max_characters' => '',
            'file_extension' => '',
            'field_hidden_dependency' => '',
            'mageworx_option_id' => '',
            'values' => array(),
            'record_id' => 0,
            'title' => '',
            'njm_option_id' => 0,
            'njm_in_group_id' => 0,
            'is_swatch' => 1,
            'price' => '',
            'image_size_x' => '',
            'image_size_y' => '',
            'mageworx_option_gallery' => 0,
            'mageworx_option_image_mode' => ($data['title']=='COM & RUSH') ? 0 : 1,
            'price_type' => 'fixed',
            'type' => ($data['title']=='COM & RUSH') ? 'checkbox' : 'drop_down'
        );
        $values = array(
            'title' => '',
            'price' => 0,
            'price_type' => 'fixed',
            'sku' => '',
            'sort_order' => 0,
            'qty' => 0,
            'manage_stock' => 0,
            'cost' => 0,
            'weight' => 0,
            'description' => '',
            'images_data' => '',
            'sku_is_valid' => '',
            'field_hidden_dependency' => '',
            'mageworx_option_type_id' => '',
            //'is_stocktab' => 0,
            //'is_customtab' => 1,
            'is_default' => 0,
            'record_id' => 0,
            'njm_option_type_id' => 0,
            'njm_image_path' => '',
            'njm_in_group_id' => 0
        );
        if(count(unserialize($rowData))) {
            
            foreach (unserialize($rowData) as $item) {
                if(isset($item['title']))
                    $prepareOption['title'] = $item['title'];
                if(isset($item['option_id']))
                    $prepareOption['njm_option_id'] = $item['option_id'];
                if(isset($item['in_group_id']))
                    $prepareOption['njm_in_group_id'] = $item['in_group_id'];
                if(isset($item['description']))
                    $prepareOption['description'] = $item['description'];
                if(isset($item['sort_order']))
                    $prepareOption['sort_order'] = $item['sort_order'];
                if(isset($item['customoptions_is_onetime']))
                    $prepareOption['one_time'] = $item['customoptions_is_onetime'];
                if(isset($item['values']) && is_array($item['values']) && count($item['values'])) {
                    $record_id = 0;
                    $data['outof'] = count($item['values']);
                    $prepareOption['values'] = array();
                    foreach ($item['values'] as $value) {
                        $values['title'] = $value['title'];
                        $values['sku'] = $value['sku'];
                        $values['sort_order'] = $optionsCount;
                        $values['price'] = $value['price'];
                        $values['price_type'] = $value['price_type'];
                        $values['record_id'] = $record_id;
                        $values['njm_option_type_id'] = $value['option_type_id'];
                        $values['njm_image_path'] = $value['image_path'];
                        $values['njm_in_group_id'] = $value['in_group_id'];
                        $optionsCount++;

                        if($canSaveImages) {
                            if(isset($value['image_path'])) {
                                $base_image = (isset($data['options'][0]['values'][$record_id]['base_image']) && $data['options'][0]['values'][$record_id]['base_image']) ? $data['options'][0]['values'][$record_id]['base_image'] : '';
                                $imageExist = ($base_image && file_exists($mediaPath.$base_image)) ? true : false;
                                
                                if(isset($data['options'][0]['values'][$record_id]['mageworx_option_type_id']) && isset($data['options'][0]['values'][$record_id]['images_data']) && !$imageExist)
                                {
                                    $fileName = str_replace(' ', '-', $value['title']).'.jpg';
                                    $fileName = str_replace('/', '-', $fileName);
                                    $fileName = str_replace('%', 'percent', $fileName);
                                    $imageFolder = '/customoptions/'.$value['image_path'].'/';
                                    $imagePath = $mediaPath.$imageFolder.$fileName;

                                    if(!file_exists($imagePath)) {
                                        $directory = $mediaPath.$imageFolder;
                                        $found = false;

                                        if (is_dir($mediaPath.$imageFolder) && $handle = opendir($mediaPath.$imageFolder)) {
                                            while($file = readdir($handle)) {
                                                if($file !== '.' && $file !== '..' ) {
                                                    if(strlen($file)> 4) {
                                                        $image = $mediaPath.$imageFolder.$file;
                                                        $existingFileName = basename($image);
                                                        $fileToCopyFullPath = $image;
                                                        $newFileFullPath = str_replace($existingFileName, $fileName, $image);
                                                        if(!@getimagesize($fileToCopyFullPath)) {
                                                            $record_id++;
                                                            continue;
                                                        }
                                                        if(!copy($fileToCopyFullPath, $newFileFullPath)) {
                                                            $record_id++;
                                                            continue;
                                                        }
                                                        $found = true;
                                                    }
                                                }
                                            }
                                            closedir($handle);
                                        }

                                        if(!$found) {
                                            //echo "<br/>skip this entry";
                                            $record_id++;
                                            continue;
                                        }
                                    }
                                    $optionsCountTemp = $optionsCount-1;
                                    $imageData2 = [
                                        'mageworx_option_type_id' => $data['options'][0]['values'][$optionsCountTemp]['mageworx_option_type_id'],
                                        'media_type' => 'image',
                                        'value' => $imageFolder.$fileName,
                                        'base_image' => 1,
                                        'tooltip_image' => 1,
                                    ];
                                    
                                    $sql = "Select * FROM " . $tableName . " WHERE mageworx_option_type_id='" . $data['options'][0]['values'][$optionsCountTemp]['mageworx_option_type_id']."'";
                                    $result = $connection->fetchAll($sql);
                                    if(!count($result)) {
                                        $connection->insert($tableName, $imageData2);
                                    }
                                    else {
                                        $sql = "Update " . $tableName . " Set value = '".$imageFolder.$fileName."' WHERE mageworx_option_type_id = '".$data['options'][0]['values'][$optionsCountTemp]['mageworx_option_type_id']."'";
                                        $connection->query($sql);
                                    }
                                    $swatchesCount++;
                                }
                            }
                        }
                        $prepareOption['record_id'] = $mainOptionsCount;
                        $prepareOption['values'][] = $values;
                        $record_id++;
                    }
                    $prepareOptions[] = $prepareOption;
                }
                $mainOptionsCount++;
            }
        }
        if($canSaveOptions) {
            if(count($prepareOptions))
                $data['options'] = $prepareOptions;
        }
        $data['swatchesCount'] = $swatchesCount;
        $data['optionsCount'] = $optionsCount;

        return $data;
    }
}