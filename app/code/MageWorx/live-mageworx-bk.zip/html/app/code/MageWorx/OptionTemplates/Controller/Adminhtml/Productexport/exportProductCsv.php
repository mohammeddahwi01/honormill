<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace MageWorx\OptionTemplates\Controller\Adminhtml\Productexport;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\App\Filesystem\DirectoryList;

class exportProductCsv extends \Magento\Catalog\Controller\Adminhtml\Product
{
    /**
     * Massactions filter
     *
     * @var Filter
     */
    protected $filter;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @param Context $context
     * @param Builder $productBuilder
     * @param Filter $filter
     * @param CollectionFactory $collectionFactory
     * @param ProductRepositoryInterface $productRepository
     */
    public function __construct(
        Context $context,
        \Magento\Catalog\Controller\Adminhtml\Product\Builder $productBuilder,
        Filter $filter,
        CollectionFactory $collectionFactory,
        ProductRepositoryInterface $productRepository = null
    ) {
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->productRepository = $productRepository
            ?: \Magento\Framework\App\ObjectManager::getInstance()->create(ProductRepositoryInterface::class);
        parent::__construct($context, $productBuilder);
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $collection = $this->filter->getCollection($this->collectionFactory->create());
        $_groupCollectionFactory = $this->_objectManager->get('MageWorx\OptionTemplates\Model\ResourceModel\Group\CollectionFactory');
        $_optionSaver = $this->_objectManager->get('\MageWorx\OptionTemplates\Model\OptionSaver');
        $_baseHelper = $this->_objectManager->get('MageWorx\OptionBase\Helper\Data');
        $resource = $this->_objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();

        $collArr = [];
        $cnt = 0;
        foreach ($collection->getItems() as $product) {
        	$_prod = $this->productRepository->getById($product->getEntityId());
        	$_pOptionsInterface = $this->_objectManager->get('Magento\Catalog\Api\ProductCustomOptionRepositoryInterface');
        	foreach ($_pOptionsInterface->getProductOptions($_prod) as $opt) {
        		$tableName = $resource->getTableName('mageworx_optiontemplates_group_option');
        		$sql = $connection->select()
	                  ->from($tableName)      
	                  ->where('option_id = ?', $opt->getGroupOptionId());
				$result = $connection->fetchRow($sql); 
				$groupName = '';
				if ($result) {
					$tableName1 = $resource->getTableName('mageworx_optiontemplates_group');
	        		$sql1 = $connection->select()
		                  ->from($tableName1)      
		                  ->where('group_id = ?', $result['group_id']);
					$result1 = $connection->fetchRow($sql1); 
        			$groupName = $result1['title'];
				}
        		$optCount = 0;
        		foreach ($opt->getValues() as $optVal) {
        			if ($optCount == 0) {
        				//$collArr[$cnt]['product_id'] = $_prod->getEntityId();
	        			$collArr[$cnt]['product_name'] = $_prod->getName();
	        			$collArr[$cnt]['product_sku'] = $_prod->getSku();
	        			$collArr[$cnt]['product_option_tempalte_name'] = $groupName;
	        			$collArr[$cnt]['product_option_title'] = $opt->getDefaultTitle();
	        			$collArr[$cnt]['product_option_id'] = $opt->getOptionId();
	        			$collArr[$cnt]['product_val_id'] = $optVal->getOptionTypeId();
	        			$collArr[$cnt]['product_val_title'] = $optVal->getTitle();
	        			$collArr[$cnt]['product_val_price'] = $optVal->getPrice();
	        			$collArr[$cnt]['product_val_pricetype'] = $optVal->getPriceType();
	        			$collArr[$cnt]['product_val_sku'] = $optVal->getSku();
	        			$collArr[$cnt]['product_val_qty'] = $optVal->getQty();
	        			$collArr[$cnt]['product_val_managestock'] = $optVal->getManageStock();
	        			$collArr[$cnt]['product_val_cost'] = $optVal->getCost();
	        			//$collArr[$cnt]['product_val_isdefault'] = $optVal->getIsDefault();
	        			$collArr[$cnt]['product_val_desc'] = $optVal->getDescription();
	        			$collArr[$cnt]['product_val_isstocktab'] = $optVal->getIsStocktab();
	        			$collArr[$cnt]['product_val_iscustomtab'] = $optVal->getIsCustomtab();
	        			$optCount++;
        			} else {
        				//$collArr[$cnt]['product_id'] = "";
	        			$collArr[$cnt]['product_name'] = "";
	        			$collArr[$cnt]['product_sku'] = "";
	        			$collArr[$cnt]['product_option_tempalte_name'] = "";
	        			$collArr[$cnt]['product_option_title'] = "";
	        			$collArr[$cnt]['product_option_id'] = $opt->getOptionId();
	        			$collArr[$cnt]['product_val_id'] = $optVal->getOptionTypeId();
	        			$collArr[$cnt]['product_val_title'] = $optVal->getTitle();
	        			$collArr[$cnt]['product_val_price'] = $optVal->getPrice();
	        			$collArr[$cnt]['product_val_pricetype'] = $optVal->getPriceType();
	        			$collArr[$cnt]['product_val_sku'] = $optVal->getSku();
	        			$collArr[$cnt]['product_val_qty'] = $optVal->getQty();
	        			$collArr[$cnt]['product_val_managestock'] = $optVal->getManageStock();
	        			$collArr[$cnt]['product_val_cost'] = $optVal->getCost();
	        			//$collArr[$cnt]['product_val_isdefault'] = $optVal->getIsDefault();
	        			$collArr[$cnt]['product_val_desc'] = $optVal->getDescription();
	        			$collArr[$cnt]['product_val_isstocktab'] = $optVal->getIsStocktab();
	        			$collArr[$cnt]['product_val_iscustomtab'] = $optVal->getIsCustomtab();
        			}
        			$cnt++;
        		}
        	}
        }
        $fileFactory = $this->_objectManager->get('Magento\Framework\App\Response\Http\FileFactory');
        
        return $fileFactory->create('product-options.csv', $this->getCsvFile($collArr), 'var');
        //return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('catalog/*/index');
    }
    public function getCsvFile($content = array())
    {
    	$filesystem = $this->_objectManager->get('\Magento\Framework\Filesystem');
    	$directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
    	$name = md5(microtime());
        $file = 'export/mpreport' . $name . '.csv';
        $directory->create('export');
        $stream = $directory->openFile($file, 'w+');
        $stream->lock();
        $headerData = array(__("Product Name"),__("Product SKU"),__("Template Name"),__("Option Title"),__("Option ID"),__("Option Value ID"),__("Option Value Title"),__("Price"),__("Price Type"),__("Option Value SKU"),__("Option Value Qty"),__("Option Value Manage Stock"),__("Option Value Cost"),__("Option Value Description"),__("Fast Ship"),__("Custom Order"));
        $stream->writeCsv($headerData);
        $last_rate = 0;
        $totalAmount = 0; 
        $totalComm = 0; 
        $cnt = 0;
        foreach ($content as $value) {
        	$stream->writeCsv($value);
        }
        $stream->unlock();
        $stream->close();
        return [
            'type' => 'filename',
            'value' => $file,
            'rm' => true  // can delete file after use
        ];
    }
}
