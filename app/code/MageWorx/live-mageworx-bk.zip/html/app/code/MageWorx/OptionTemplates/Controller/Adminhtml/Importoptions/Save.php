<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace MageWorx\OptionTemplates\Controller\Adminhtml\Importoptions;

use Magento\Backend\App\Action;
use Magento\Framework\App\TemplateTypesInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\ResultFactory;

class Save extends Action
{
    /**
     * Save Newsletter Template
     *
     * @return void
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $request = $this->getRequest();
        if (!$request->isPost()) {
            $this->getResponse()->setRedirect($this->getUrl('*/new'));
        }

        $filesystem = $this->_objectManager->get('\Magento\Framework\Filesystem');
        $mediaDirectory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $fileUploaderFactory = $this->_objectManager->get('\Magento\MediaStorage\Model\File\UploaderFactory');
        try{
            $target = $mediaDirectory->getAbsolutePath('importoptions/');        
            $uploader = $fileUploaderFactory->create(['fileId' => 'upload_csv']);
            $uploader->setAllowedExtensions(['csv']);
            $uploader->setAllowRenameFiles(true);
            $result = $uploader->save($target);

            if ($result['file']) {
                $csvPath = $result['path'].$result['file'];
                $fileCsv = $this->_objectManager->get('\Magento\Framework\File\Csv');
                $csvDt = $fileCsv->getData($csvPath);
                if(count($csvDt)) {
                    $tmpArr = [];
                    $tmpCount = 0;
                    foreach ($csvDt as $ind => $val) {
                        if ($ind == 0) {
                            continue;
                        }
                        if ($val[0] !== '') {
                            $tmpCount++;
                            $pname = $val[0];
                            $psku = $val[1];
                            $templatename = $val[2];
                            $opttitle = $val[3];
                        }
                        $opId = $val[4];
                        $opValId = $val[5];
                        $tmpArr[$tmpCount]['pname'] = $pname;
                        $tmpArr[$tmpCount]['psku'] = $psku;
                        $tmpArr[$tmpCount]['template_name'] = $templatename;
                        $tmpArr[$tmpCount]['values'][$opValId] = [
                            'poption_title' => $opttitle,
                            'poption_id' => $val[4],
                            'pval_id' => $val[5],
                            'pval_title' => $val[6],
                            'pval_price' => $val[7],
                            'pval_pricetype' => $val[8],
                            'pval_sku' => $val[9],
                            'pval_qty' => $val[10],
                            'pval_managestock' => $val[11],
                            'pval_cost' => $val[12],
                            'pval_desc' => $val[13],
                            'pval_isstocktab' => $val[14],
                            'pval_iscustomtab' => $val[15],
                        ];
                    }

                    if (count($tmpArr) > 0) {
                        foreach ($tmpArr as $value) {
                            if (isset($value['values']) && count($value['values']) > 0) {
                                $updateOptIds = array_unique(array_column($value['values'], 'poption_id'));
                                $pData = $this->_objectManager->create('Magento\Catalog\Api\ProductRepositoryInterface')->get($value['psku']);
                                $opts = array();
                                $pOpt = array();
                                foreach ($pData->getOptions() as $opt) {
                                    if (in_array($opt->getOptionId(), $updateOptIds)) {
                                        $pOpt = $opt->getValues();
                                    }
                                }
                                $valuesData = array();
                                if (!empty($pOpt)) {
                                    foreach ($pOpt as $vals) {
                                        if (array_key_exists($vals->getOptionTypeId(), $value['values'])) {
                                            $valNewData = $value['values'][$vals->getOptionTypeId()];

                                            $price =  number_format($valNewData['pval_price'], 4); 
                                            $vals->setTitle($valNewData['pval_title']);
                                            $vals->setPrice($valNewData['pval_price']);
                                            $vals->setPriceType($valNewData['pval_pricetype']);
                                            $vals->setIsStocktab($valNewData['pval_isstocktab']);
                                            $vals->setIsCustomtab($valNewData['pval_iscustomtab']);
                                            $vals->setIsCustomtab($valNewData['pval_iscustomtab']);
                                            $vals->setQty($valNewData['pval_qty']);
                                            $vals->setManageStock($valNewData['pval_managestock']);
                                            $vals->setDescription($valNewData['pval_desc']);
                                            $vals->setCost($valNewData['pval_cost']);
                                            $vals->setSku($valNewData['pval_sku']);
                                            $vals->setData('store_id',0);
                                            $valuesData[$vals->getOptionTypeId()] = $vals->getData();
                                            $vals->save();
                                        }
                                    }
                                    $pData->setCanSaveCustomOptions(true)->save();
                                }
                            }
                        }
                    }
                }
                
                $file = $this->_objectManager->get('\Magento\Framework\Filesystem\Driver\File');
                
                if ($file->isExists($csvPath))  {
                    $file->deleteFile($csvPath);
                }

                $this->messageManager->addSuccess(__('File has been successfully imported.')); 
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

        return $resultRedirect->setPath('*/*/new');
    }
}