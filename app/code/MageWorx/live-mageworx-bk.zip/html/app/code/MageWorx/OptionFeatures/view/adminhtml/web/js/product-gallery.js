/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*jshint jquery:true*/
define([
    'jquery',
    'underscore',
    'mage/template',
    'uiRegistry',
    'jquery/ui',
    'baseImage',
    'productGallery'
], function ($, _, mageTemplate, registry) {
    'use strict';

    // Extension for mage.productGallery - Add advanced settings block
    $.widget('mage.mageworxProductGallery', $.mage.productGallery, {

        /**
         * Set image as main
         * @param {Object} imageData
         * @private
         */
        setBase: function (imageData) {
            var baseImage = this.options.types.base_image,
                sameImages = $.grep(
                    $.map(this.options.types, function (el) {
                        return el;
                    }),
                    function (el) {
                        return el.value === baseImage.value;
                    }
                ),
                isImageOpened = this.findElement(imageData).hasClass('active');

            $.each(sameImages, $.proxy(function (index, image) {
                // if (image.code != 'replace_main_gallery_image') {
                    this.element.trigger('setImageType', {
                        type: image.code,
                        imageData: imageData
                    });

                    if (isImageOpened) {
                        this.element.find('.item').addClass('selected');
                        this.element.find('[data-role=type-selector]').prop({
                            'checked': true
                        });
                    }
                // }
            }, this));
        },
    });

    return $.mage.mageworxProductGallery;
});
