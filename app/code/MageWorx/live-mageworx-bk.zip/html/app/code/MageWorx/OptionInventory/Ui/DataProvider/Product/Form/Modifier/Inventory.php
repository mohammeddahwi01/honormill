<?php
/**
 * Copyright © 2016 MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace MageWorx\OptionInventory\Ui\DataProvider\Product\Form\Modifier;

use Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\AbstractModifier;
use Magento\Framework\Stdlib\ArrayManager;

class Inventory extends AbstractModifier implements \MageWorx\OptionBase\Ui\DataProvider\Product\Form\Modifier\ModifierInterface
{
    const FIELD_MANAGE_STOCK_NAME = 'manage_stock';
    const FIELD_QUANTITY_NAME = 'qty';

    /**
     * @var ArrayManager
     */
    protected $arrayManager;

    /**
     * @var array
     */
    protected $meta = [];

    /**
     * @param ArrayManager $arrayManager
     */
    public function __construct(
        ArrayManager $arrayManager
    ) {
        $this->arrayManager = $arrayManager;
    }

    /**
     * {@inheritdoc}
     */
    public function modifyData(array $data)
    {
        return $data;
    }

    /**
     * {@inheritdoc}
     */
    public function modifyMeta(array $meta)
    {
        $this->meta = $meta;

        $this->addInventoryFields();
        $this->addFilterRelationFields();

        return $this->meta;
    }

    protected function addInventoryFields()
    {
        $groupCustomOptionsName =
            \Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\CustomOptions::GROUP_CUSTOM_OPTIONS_NAME;
        $inventoryFields = $this->getInventoryFields();

        $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
        ['container_option']['children']['values']['children']['record']['children'] = array_replace_recursive(
            $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
            ['container_option']['children']['values']['children']['record']['children'],
            $inventoryFields
        );
    }

    public function addFilterRelationFields() {
        $groupCustomOptionsName =
            \Magento\Catalog\Ui\DataProvider\Product\Form\Modifier\CustomOptions::GROUP_CUSTOM_OPTIONS_NAME;
        $optFields = $this->getOptFields();

        $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
        ['container_option']['children']['values']['children']['record']['children'] = array_replace_recursive(
            $this->meta[$groupCustomOptionsName]['children']['options']['children']['record']['children']
            ['container_option']['children']['values']['children']['record']['children'],
            $optFields
        );
    }

    public function getOptFields() {        
        $sizeOpt = $this->getOptionFormattedArray('size');
        $colorOpt = $this->getOptionFormattedArray('color');
        $fabricOpt = $this->getOptionFormattedArray('fabric');
        // echo "<pre>";
        // print_r($colorOpt);
        // exit();
        $fields = [
            'opt_size' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'dataType' => \Magento\Ui\Component\Form\Element\DataType\Text::NAME,
                            'formElement' => \Magento\Ui\Component\Form\Element\Select::NAME,
                            'componentType' => \Magento\Ui\Component\Form\Field::NAME,
                            'dataScope' => 'opt_size',
                            'label' => __('Option Size'),
                            'options' => $sizeOpt,
                            /*'value' => [],*/
                            'visible' => true,
                            'disabled' => false,
                            'additionalClasses' => 'showhide-fields',
                            'columnsHeaderClasses' => 'showhide-fields',
                        ],
                    ],
                ],
            ],
            'opt_color' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'dataType' => \Magento\Ui\Component\Form\Element\DataType\Text::NAME,
                            'formElement' => \Magento\Ui\Component\Form\Element\Select::NAME,
                            'componentType' => \Magento\Ui\Component\Form\Field::NAME,
                            'dataScope' => 'opt_color',
                            'label' => __('Option Color'),
                            'options' => $colorOpt,
                            /*'value' => [],*/
                            'visible' => true,
                            'disabled' => false,
                            'additionalClasses' => 'showhide-fields',
                            'columnsHeaderClasses' => 'showhide-fields',
                        ],
                    ],
                ],
            ],
            'opt_fabric' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'dataType' => \Magento\Ui\Component\Form\Element\DataType\Text::NAME,
                            'formElement' => \Magento\Ui\Component\Form\Element\Select::NAME,
                            'componentType' => \Magento\Ui\Component\Form\Field::NAME,
                            'dataScope' => 'opt_fabric',
                            'label' => __('Option Fabric/Material'),
                            'options' => $fabricOpt,
                            /*'value' => [],*/
                            'visible' => true,
                            'disabled' => false,
                            'additionalClasses' => 'showhide-fields',
                            'columnsHeaderClasses' => 'showhide-fields',
                        ],
                    ],
                ],
            ]
        ];

        return $fields;
    }

    public function getOptionFormattedArray($code)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $eavModel = $objectManager->create('Magento\Catalog\Model\ResourceModel\Eav\Attribute');
        $eavConfig = $objectManager->create('Magento\Eav\Model\Config');
        $eavAttrValues = $objectManager->create('\Magento\Eav\Model\ResourceModel\Entity\Attribute\Option\Collection');
        $AttributeDetails = $eavConfig->getAttribute("catalog_product", $code);
        $AttributeId = $AttributeDetails->getAttributeId();
        $AttrOptions =  $eavAttrValues->setPositionOrder('asc')->setStoreFilter()->setAttributeFilter($AttributeId)->load();
        $ret = array();
        $ret[] = ['value'=> '', 'label' => 'None']; 
        if ($AttrOptions->getData() != NULL) {
            foreach ($AttrOptions->getData() as $value) {
                $ret[] = ['value' => $value['option_id'], 'label' => $value['default_value']];
            }    
        }
        return $ret;
    }

    /**
     * Create additional custom options fields
     *
     * @return array
     */
    protected function getInventoryFields()
    {
        $fields = [
            'qty' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'label' => __('Quantity'),
                            'componentType' => \Magento\Ui\Component\Form\Field::NAME,
                            'formElement' => \Magento\Ui\Component\Form\Element\Input::NAME,
                            'dataScope' => static::FIELD_QUANTITY_NAME,
                            'dataType' => \Magento\Ui\Component\Form\Element\DataType\Number::NAME,
                            'fit' => true,
                            'validation' => [
                                'validate-number' => true,
                            ],
                            'sortOrder' => 100,
                            'additionalClasses' => 'showhide-fields',
                            'columnsHeaderClasses' => 'showhide-fields',
                        ],
                        'imports' => [
                            'seeminglyArbitraryValue' => '${ $.provider }:data.form_id_field_name',
                        ],
                        'exports' => [
                            'seeminglyArbitraryValue' => '${ $.externalProvider }:params.form_id_field_name',
                        ],
                    ],
                ],
            ],
            'manage_stock' => [
                'arguments' => [
                    'data' => [
                        'config' => [
                            'label' => __('Manage Stock'),

                            'componentType' => \Magento\Ui\Component\Form\Field::NAME,
                            'formElement' => \Magento\Ui\Component\Form\Element\Checkbox::NAME,
                            'dataScope' => static::FIELD_MANAGE_STOCK_NAME,
                            'dataType' => \Magento\Ui\Component\Form\Element\DataType\Number::NAME,
                            'prefer' => 'toggle',
                            'valueMap' => [
                                'true' => \MageWorx\OptionInventory\Helper\Stock::MANAGE_STOCK_ENABLED,
                                'false' => \MageWorx\OptionInventory\Helper\Stock::MANAGE_STOCK_DISABLED,
                            ],
                            'sortOrder' => 110,
                            'additionalClasses' => 'showhide-fields',
                            'columnsHeaderClasses' => 'showhide-fields',
                        ],
                    ],
                ],
            ],
        ];

        return $fields;
    }

    /**
     * Check is current modifier for the product only
     *
     * @return bool
     */
    public function isProductScopeOnly()
    {
        return false;
    }
}
